const mongoose = require('mongoose');

const colorSchema = new mongoose.Schema({
  hex: { type: String, default: '' },
  name: { type: String, default: '' }
}, { _id: false });

const typographySchema = new mongoose.Schema({
  fontFamily: { type: String, default: '' },
  fontSize: { type: String, default: '' },
  fontWeight: { type: String, default: '' },
  lineHeight: { type: String, default: '' },
  letterSpacing: { type: String, default: '' }
}, { _id: false });

const brandSettingsSchema = new mongoose.Schema({
  // Multi-tenancy
  organizationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: [true, 'Organization ID is required'],
    index: true
  },

  // Project reference
  projectId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true,
    unique: true
  },

  // Brand Manual PDF
  brandManual: {
    fileName: { type: String },
    filePath: { type: String },
    publicId: { type: String },
    uploadedAt: { type: Date }
  },

  // Brand Colors
  colors: {
    primary: { type: colorSchema, default: () => ({ hex: '', name: 'Primary' }) },
    secondary: { type: colorSchema, default: () => ({ hex: '', name: 'Secondary' }) },
    tertiary: { type: colorSchema, default: () => ({ hex: '', name: 'Tertiary' }) },
    accent: { type: colorSchema, default: () => ({ hex: '', name: 'Accent' }) },
    background: { type: colorSchema, default: () => ({ hex: '', name: 'Background' }) },
    text: { type: colorSchema, default: () => ({ hex: '', name: 'Text' }) }
  },

  // Typography Settings
  typography: {
    title: {
      type: typographySchema,
      default: () => ({
        fontFamily: '',
        fontSize: '',
        fontWeight: '700',
        lineHeight: '',
        letterSpacing: ''
      })
    },
    subtitle: {
      type: typographySchema,
      default: () => ({
        fontFamily: '',
        fontSize: '',
        fontWeight: '500',
        lineHeight: '',
        letterSpacing: ''
      })
    },
    body: {
      type: typographySchema,
      default: () => ({
        fontFamily: '',
        fontSize: '',
        fontWeight: '400',
        lineHeight: '1.6',
        letterSpacing: ''
      })
    }
  },

  // Logo Files
  logos: {
    primary: {
      fileName: { type: String },
      filePath: { type: String },
      publicId: { type: String },
      uploadedAt: { type: Date }
    },
    secondary: {
      fileName: { type: String },
      filePath: { type: String },
      publicId: { type: String },
      uploadedAt: { type: Date }
    },
    favicon: {
      fileName: { type: String },
      filePath: { type: String },
      publicId: { type: String },
      uploadedAt: { type: Date }
    }
  },

  // Additional Brand Assets
  additionalAssets: [{
    fileName: { type: String },
    filePath: { type: String },
    publicId: { type: String },
    uploadedAt: { type: Date, default: Date.now },
    description: { type: String }
  }],

  // Brand Guidelines Text (extracted or manually entered)
  brandGuidelines: {
    tone: { type: String },
    voice: { type: String },
    dos: [{ type: String }],
    donts: [{ type: String }],
    additionalNotes: { type: String }
  },

  // Extraction Status
  extractionStatus: {
    colorsExtracted: { type: Boolean, default: false },
    typographyExtracted: { type: Boolean, default: false },
    extractedAt: { type: Date },
    extractionError: { type: String }
  },

  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// Indexes
brandSettingsSchema.index({ organizationId: 1, projectId: 1 });

// Method to generate brand prompt for AI
brandSettingsSchema.methods.generateBrandPrompt = function() {
  const parts = [];

  // Colors
  if (this.colors?.primary?.hex) {
    parts.push(`Primary Color: ${this.colors.primary.hex}${this.colors.primary.name ? ` (${this.colors.primary.name})` : ''}`);
  }
  if (this.colors?.secondary?.hex) {
    parts.push(`Secondary Color: ${this.colors.secondary.hex}${this.colors.secondary.name ? ` (${this.colors.secondary.name})` : ''}`);
  }
  if (this.colors?.tertiary?.hex) {
    parts.push(`Tertiary Color: ${this.colors.tertiary.hex}`);
  }
  // if (this.colors?.accent?.hex) {
  //   parts.push(`Accent Color: ${this.colors.accent.hex}`);
  // }
  // if (this.colors?.background?.hex) {
  //   parts.push(`Background Color: ${this.colors.background.hex}`);
  // }
  // if (this.colors?.text?.hex) {
  //   parts.push(`Text Color: ${this.colors.text.hex}`);
  // }

  // Typography
  if (this.typography?.title?.fontFamily) {
    parts.push(`Title Typography: ${this.typography.title.fontFamily}${this.typography.title.fontSize ? `, Size: ${this.typography.title.fontSize}` : ''}${this.typography.title.fontWeight ? `, Weight: ${this.typography.title.fontWeight}` : ''}`);
  }
  if (this.typography?.subtitle?.fontFamily) {
    parts.push(`Subtitle Typography: ${this.typography.subtitle.fontFamily}${this.typography.subtitle.fontSize ? `, Size: ${this.typography.subtitle.fontSize}` : ''}`);
  }
  if (this.typography?.body?.fontFamily) {
    parts.push(`Body Typography: ${this.typography.body.fontFamily}${this.typography.body.fontSize ? `, Size: ${this.typography.body.fontSize}` : ''}`);
  }

  // Brand Guidelines
  if (this.brandGuidelines?.tone) {
    parts.push(`Brand Tone: ${this.brandGuidelines.tone}`);
  }
  if (this.brandGuidelines?.voice) {
    parts.push(`Brand Voice: ${this.brandGuidelines.voice}`);
  }

  return parts.length > 0 ? `Brand Guidelines:\n${parts.join('\n')}` : '';
};

module.exports = mongoose.model('BrandSettings', brandSettingsSchema);