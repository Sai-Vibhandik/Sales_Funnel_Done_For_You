const axios = require('axios');
const pdf = require('pdf-parse');
const fs = require('fs');
const path = require('path');

// Common font families for matching
const COMMON_FONTS = [
  'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Poppins', 'Raleway',
  'Nunito', 'Ubuntu', 'Playfair Display', 'Merriweather', 'Lora', 'Source Sans Pro',
  'PT Sans', 'Muli', 'Work Sans', 'Quicksand', 'Rubik', 'Heebo', 'Barlow',
  'Arial', 'Helvetica', 'Georgia', 'Times New Roman', 'Verdana', 'Tahoma'
];

// Common hex color regex patterns
const HEX_COLOR_REGEX = /#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})\b/g;

/**
 * Extract brand information from a PDF using AI service
 * @param {string} fileUrl - URL or path to the PDF file
 * @returns {Object} Extracted brand data
 */
async function extractBrandInfo(fileUrl) {
  try {
    let pdfBuffer;
    let pdfText = '';

    // Check if it's a URL or local file
    if (fileUrl.startsWith('http')) {
      // Download PDF from URL (Cloudinary or other)
      try {
        console.log('Downloading PDF from URL:', fileUrl);
        const response = await axios.get(fileUrl, {
          responseType: 'arraybuffer',
          timeout: 30000
        });
        pdfBuffer = Buffer.from(response.data);
        console.log('PDF downloaded successfully, size:', pdfBuffer.length);
      } catch (downloadError) {
        console.error('PDF download error:', downloadError.message);
        return {
          colors: null,
          typography: null,
          error: 'Could not download PDF file: ' + downloadError.message
        };
      }
    } else {
      // Read local file
      if (!fs.existsSync(fileUrl)) {
        return {
          colors: null,
          typography: null,
          error: 'PDF file not found'
        };
      }
      pdfBuffer = fs.readFileSync(fileUrl);
    }

    // Parse PDF to extract text
    try {
      console.log('Parsing PDF...');
      const pdfData = await pdf(pdfBuffer);
      pdfText = pdfData.text || '';
      console.log('PDF parsed, text length:', pdfText.length);
    } catch (pdfError) {
      console.error('PDF parse error:', pdfError.message);
      // Continue with empty text - will use regex fallback
    }

    // Try AI extraction first, fallback to regex
    const aiExtracted = await extractWithAI(pdfText, fileUrl);
    return aiExtracted;

  } catch (error) {
    console.error('Brand extraction error:', error);
    return {
      colors: null,
      typography: null,
      error: 'Failed to extract brand information: ' + error.message
    };
  }
}

/**
 * Use AI service to extract brand information from text
 * @param {string} text - Extracted PDF text
 * @param {string} fileUrl - PDF URL for context
 * @returns {Object} Structured brand data
 */
async function extractWithAI(text, fileUrl) {
  // First try regex extraction as it's more reliable
  const regexResult = extractWithRegex(text);

  // Try AI if available (with short timeout)
  try {
    const aiServiceUrl = process.env.AI_SERVICE_URL || 'http://localhost:11434';

    // Check if AI service is available (quick check)
    try {
      await axios.get(aiServiceUrl.replace('/api', ''), { timeout: 2000 });
    } catch {
      console.log('AI service not available, using regex extraction');
      return regexResult;
    }

    const prompt = `Analyze the following brand manual content and extract brand guidelines in JSON format.

Content from brand manual:
${text.substring(0, 3000)}

Extract and return ONLY a valid JSON object with this exact structure:
{
  "colors": {
    "primary": { "hex": "#XXXXXX", "name": "Color Name" },
    "secondary": { "hex": "#XXXXXX", "name": "Color Name" },
    "tertiary": { "hex": "#XXXXXX", "name": "Color Name" }
  },
  "typography": {
    "title": { "fontFamily": "Font Name", "fontSize": "48px", "fontWeight": "700" },
    "subtitle": { "fontFamily": "Font Name", "fontSize": "24px", "fontWeight": "500" },
    "body": { "fontFamily": "Font Name", "fontSize": "16px", "fontWeight": "400" }
  }
}

Rules:
- Convert all colors to hex format (#RRGGBB)
- If a value is not found, use empty string ""
- Look for "primary color", "main color", "brand color", "secondary color"
- For typography, look for "heading font", "title font", "body font"

Return ONLY the JSON object.`;

    const response = await axios.post(`${aiServiceUrl}/api/generate`, {
      model: process.env.AI_MODEL || 'llama2',
      prompt,
      stream: false
    }, { timeout: 30000 });

    const aiResponseText = response.data?.response || '';
    const jsonMatch = aiResponseText.match(/\{[\s\S]*\}/);

    if (jsonMatch) {
      try {
        const extractedData = JSON.parse(jsonMatch[0]);
        // Merge with regex results, preferring AI results
        return {
          colors: {
            primary: extractedData.colors?.primary || regexResult.colors?.primary || { hex: '', name: 'Primary' },
            secondary: extractedData.colors?.secondary || regexResult.colors?.secondary || { hex: '', name: 'Secondary' },
            tertiary: extractedData.colors?.tertiary || regexResult.colors?.tertiary || { hex: '', name: 'Tertiary' }
          },
          typography: {
            title: extractedData.typography?.title || regexResult.typography?.title || { fontFamily: '', fontSize: '', fontWeight: '700' },
            subtitle: extractedData.typography?.subtitle || regexResult.typography?.subtitle || { fontFamily: '', fontSize: '', fontWeight: '500' },
            body: extractedData.typography?.body || regexResult.typography?.body || { fontFamily: '', fontSize: '', fontWeight: '400' }
          }
        };
      } catch (parseError) {
        console.log('Failed to parse AI response, using regex extraction');
        return regexResult;
      }
    }

    return regexResult;
  } catch (error) {
    console.log('AI extraction failed, using regex:', error.message);
    return regexResult;
  }
}

/**
 * Fallback extraction using regex patterns
 * @param {string} text - Text to extract from
 * @returns {Object} Extracted data
 */
function extractWithRegex(text) {
  console.log('Using regex extraction...');

  const colors = {
    primary: { hex: '', name: 'Primary' },
    secondary: { hex: '', name: 'Secondary' },
    tertiary: { hex: '', name: 'Tertiary' }
  };

  const typography = {
    title: { fontFamily: '', fontSize: '', fontWeight: '700' },
    subtitle: { fontFamily: '', fontSize: '', fontWeight: '500' },
    body: { fontFamily: '', fontSize: '', fontWeight: '400' }
  };

  // Extract hex colors
  const hexMatches = [...text.matchAll(HEX_COLOR_REGEX)];
  const foundColors = hexMatches
    .map(m => m[0])
    .filter(c => {
      const lower = c.toLowerCase();
      // Filter out common UI colors
      return lower !== '#ffffff' &&
             lower !== '#fff' &&
             lower !== '#000000' &&
             lower !== '#000' &&
             lower !== '#ccc' &&
             lower !== '#cccccc' &&
             lower !== '#eee' &&
             lower !== '#eeeeee' &&
             lower !== '#ddd' &&
             lower !== '#dddddd';
    });

  // Assign found colors to brand color slots
  if (foundColors.length >= 1) colors.primary.hex = foundColors[0];
  if (foundColors.length >= 2) colors.secondary.hex = foundColors[1];
  if (foundColors.length >= 3) colors.tertiary.hex = foundColors[2];

  // Extract font families
  const fontPatterns = [
    /(?:font[- ]?family|typeface|font)[:\s]*["']?([A-Za-z\s]+)["']?/gi,
    /(?:heading|title)[:\s]*(?:font|typeface)[:\s]*["']?([A-Za-z\s]+)["']?/gi
  ];

  const foundFonts = [];
  for (const pattern of fontPatterns) {
    const matches = [...text.matchAll(pattern)];
    for (const match of matches) {
      const fontName = match[1]?.trim();
      if (fontName && COMMON_FONTS.some(f => f.toLowerCase() === fontName.toLowerCase())) {
        if (!foundFonts.includes(fontName)) {
          foundFonts.push(fontName);
        }
      }
    }
  }

  // Assign found fonts
  if (foundFonts.length >= 1) typography.title.fontFamily = foundFonts[0];
  if (foundFonts.length >= 2) typography.subtitle.fontFamily = foundFonts[1];
  if (foundFonts.length >= 3) typography.body.fontFamily = foundFonts[2];
  // If only one font, use it for all
  if (foundFonts.length === 1) {
    typography.subtitle.fontFamily = foundFonts[0];
    typography.body.fontFamily = foundFonts[0];
  }

  // Extract font sizes
  const sizePattern = /(?:font[- ]?size|size)[:\s]*(\d+)(?:px|pt|rem|em)?/gi;
  const sizeMatches = [...text.matchAll(sizePattern)];
  const sizes = [...new Set(sizeMatches.map(m => m[1] + 'px'))];

  if (sizes.length >= 1) typography.title.fontSize = sizes[0];
  if (sizes.length >= 2) typography.subtitle.fontSize = sizes[1];
  if (sizes.length >= 3) typography.body.fontSize = sizes[2];

  console.log('Regex extraction complete:', { colors, typography });

  return { colors, typography };
}

/**
 * Validate and clean extracted data
 * @param {Object} data - Extracted data
 * @returns {Object} Cleaned data
 */
function validateExtractedData(data) {
  const cleaned = {
    colors: data.colors || {},
    typography: data.typography || {}
  };

  // Validate hex colors
  for (const key of ['primary', 'secondary', 'tertiary']) {
    if (cleaned.colors[key]?.hex) {
      const hex = cleaned.colors[key].hex;
      if (!/^#[0-9A-Fa-f]{6}$/.test(hex)) {
        // Try to fix common issues
        if (/^[0-9A-Fa-f]{6}$/.test(hex)) {
          cleaned.colors[key].hex = '#' + hex;
        } else {
          cleaned.colors[key].hex = '';
        }
      }
    }
  }

  // Clean typography data
  for (const key of ['title', 'subtitle', 'body']) {
    if (cleaned.typography[key]) {
      if (!cleaned.typography[key].fontFamily) {
        cleaned.typography[key].fontFamily = '';
      }
      if (!cleaned.typography[key].fontSize) {
        cleaned.typography[key].fontSize = '';
      }
      if (!cleaned.typography[key].fontWeight) {
        cleaned.typography[key].fontWeight = key === 'title' ? '700' : key === 'subtitle' ? '500' : '400';
      }
    }
  }

  return cleaned;
}

module.exports = {
  extractBrandInfo,
  extractWithRegex,
  COMMON_FONTS
};